python HW3_Main.py
