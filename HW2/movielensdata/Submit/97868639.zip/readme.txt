HW2

Time to complete ~2 hours, 45 minutes

Running on my Dell, i7, in a linux virtual machine 
running Linux Mint 18.1, Python 2.7
under Windows 10

Program prints 

"*** Complete ***" 

on completion

