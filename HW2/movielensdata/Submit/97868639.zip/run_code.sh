#!/bin/sh
# Marcus Blaisdell
# CptS 315
# Homework #2
# 2/28/18
# Prof. Jana Doppa
#
# Linux script to run python program


python2.7 ./HW2_Main.py
